for i in range(0 ,150 , 1):
    print (i)

for i in range(0,1000,5):
    print(i)   


for i in range(0,100,1):
    if i%5==0:
        print("coding")
    elif i%10==0:
        print("Coding DoJo")   
    else:
        print(i)    


sum =0
for i in range (0,500000,1):
    if i%2 !=0:
        sum+=i
print(sum)        


for i in range (2018,0,-4):
    print(i)        


low_num=2
high_Num=9
mult=3
for i in range (low_num,high_Num + 1):
    if i%mult ==0:
        print(i)    






