print("hello world")

name="yasser alzoubi"
print("Hello",name)
print("Hello "+name)
number=5
print("Hello" , number , "!")
number=6
print("Hello " + str(number) + "!")

food="piza"
food2="lazania"
print("I have to eat", food ,"and", food2)

food="piza"
food2="lazania"
print(f"I have to eat", {food} ,"and", {food2})
